<?php 
namespace App\Service;

class CalculatorService
{
    public function addition($value1, $value2)
    {
        return $value1 + $value2;
    }
}