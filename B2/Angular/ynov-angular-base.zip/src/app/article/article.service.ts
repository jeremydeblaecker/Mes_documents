import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ArticleService {
  /* les services sont utilisés généralement pour tout ce qui est échange entre component et appel vers l'api */
  constructor(private http: HttpClient) {}

  callArticle(id: string): Observable<any> {
    /* sous angular les requetes ajax passent par un observable (librairie rxjs) */
    return this.http.get<any>(`article?id=${id}`);
  }
}
