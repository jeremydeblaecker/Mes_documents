import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { map, timeout } from 'rxjs/operators';
import { ArticleService } from './article.service';
import { observable } from 'rxjs';

@Component({
  selector: 'app-article',
  templateUrl: './article.component.html',
  styleUrls: ['./article.component.scss']
})
export class ArticleComponent implements OnInit {
  name: string = null;
  data: any = null;
  popup = false;
  type = 'image';

  constructor(private route: ActivatedRoute, private articles: ArticleService) {}

  ngOnInit() {
    console.log(this.route.params);
    console.log(this.name);
    /*
    appel ajax depuis le component, appel vers une fonction incluse dans le fichier article.service.ts
    comme une requete ajax passe par un observable, on souscrit à celui-ci. le retour a 3 callback qui sont optionnels
    - succès
    - erreur
    - complet

    observable.subscribe( success, error, complet);
    observable.subscribe(
      succes => {},
      error => {},
      complet => {}
    )
    dans l'exemple si-dessous, les 2 premiers callback (succés et erreur) sont implémentés.
    */
    this.route.params.subscribe(
      param => {
        this.name = param.id;
        this.articles.callArticle(this.name).subscribe(art => {
          this.data = art;
        });
      },
      err => {
        this.data = err;
      }
    );
  }
  /*
  sous angular les functions sont toujours écrites sans mettre function devant

  les fonctions peuvent être défini en private, public
  nous n'avons pas function nomdelafonction ()
  */
  showPopup() {
    this.popup = !this.popup;
    console.log(this.popup);
  }
}
