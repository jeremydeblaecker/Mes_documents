import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-article-actions',
  templateUrl: './article-actions.component.html',
  styleUrls: ['./article-actions.component.scss']
})
export class ArticleActionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
