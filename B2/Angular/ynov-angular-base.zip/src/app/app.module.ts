import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ArticleComponent } from './article/article.component';
import { HttpClientModule } from '@angular/common/http';
import { ArticleActionsComponent } from './article/article-actions/article-actions.component';
import { ArticleImageComponent } from './article/article-image/article-image.component';

@NgModule({
  declarations: [AppComponent, ArticleComponent, ArticleActionsComponent, ArticleImageComponent],
  imports: [BrowserModule, HttpClientModule, AppRoutingModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
