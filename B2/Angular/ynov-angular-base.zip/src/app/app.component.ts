import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'discover';
/* tableau contenant les articles pour la simulation */
  articles = [
    { name: 'home', id: null, type: 'image' },
    { name: 'cool', id: '1', type: 'text' },
    { name: 'top', id: '2', type: 'sound' },
    { name: 'awesome', id: '3', type: 'text' },
    { name: 'wunderbach', id: '4', type: 'sound' }
  ];
}
