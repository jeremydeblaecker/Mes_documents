package com.ecole;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;

@Data
public class Trace {

    private Long id;

    private List<Double[]> listePositions;
    private Double dplus;
    private String idClient;

    private LocalDateTime timeStamp;

    public Trace() {

    }

//    public Trace(GPX gpx, Double dPlusCumul) {
//	this.listePositions = new ArrayList<>();
//	Double[] position = new Double[3];
//	gpx.tracks().flatMap(Track::segments).flatMap(TrackSegment::points).forEach(f -> {
//	    // pour chaque point je
//	    // récupère les coordonnées
//	    // lat et lon que je met
//	    // dans un ArrayLatLonElev
//	    position[0] = f.getLatitude().doubleValue();
//
//	    position[1] = f.getLongitude().doubleValue();
//	    if (f.getElevation().isPresent())
//		position[2] = f.getElevation().get().doubleValue();
//
//	    listePositions.add(position);
//	});
//
//	this.setIdClient(gpx.getCreator());
//	this.setTimeStamp(LocalDateTime.now());
//	this.setDplus(dPlusCumul);
//	// this.setTime(LocalDateTime.now());
//	// LocalDateTime localDateTime= dateTimeService.convertReceivedDateTime(
//	// position.getTime());
//
//	// logger.log(Level.INFO,"la positionEntity instanciée est "+ this.toString());
//
//    }
}
