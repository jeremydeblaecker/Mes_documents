package com.ecole;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.ecole.tasks.MoveTask;

public class ApplicationMain {

    public static void main(String[] args) throws IOException, InterruptedException {
	String scanFolderPath = "work/ecoute";
	String workFolderPath = "work/enCours";
	String computedFolderPath = "work/termine";

	File scanDirFile = new File(scanFolderPath);
	File workDirFile = new File(workFolderPath);
	File computedDirFile = new File(computedFolderPath);

	if (!workDirFile.exists()) {
	    workDirFile.mkdirs();
	}
	if (!scanDirFile.exists()) {
	    scanDirFile.mkdirs();
	}
	if (!computedDirFile.exists()) {
	    computedDirFile.mkdirs();
	}

	LocalDateTime startTime = LocalDateTime.now();
	System.out.println("début du traitement à: " + startTime);
	List<Thread> threadList = new ArrayList<Thread>();

	Files.list(scanDirFile.toPath())
		.forEach(f -> threadList.add(new Thread(new MoveTask(f.toFile(), workDirFile))));
	System.out.println("démarrage des traitements  parralleles dans " + threadList.size() + "threads à lancer.");
	for (Thread t : threadList) {
	    t.start();

	}
	for (Thread t : threadList) {
	    t.join();
	}

    }
}
