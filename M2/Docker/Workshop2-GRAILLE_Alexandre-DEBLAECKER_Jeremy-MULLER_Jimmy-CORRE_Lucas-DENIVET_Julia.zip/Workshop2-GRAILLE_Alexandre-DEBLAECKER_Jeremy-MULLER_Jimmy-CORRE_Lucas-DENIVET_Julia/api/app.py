from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://docker:password@db:3306/db'
db = SQLAlchemy(app)
CORS(app)

@app.before_first_request
def create_table():
    db.create_all()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50))
    lastname = db.Column(db.String(50))
    age = db.Column(db.Integer)

@app.route('/add', methods=['POST'])
def register():
    firstname = request.form['firstname']
    lastname = request.form['lastname']
    age = request.form['age']
    
    if not firstname or not lastname or not age:
        return {'error': 'Missing information'}, 400
    
    user = User(firstname=firstname, lastname=lastname, age=age)
    db.session.add(user)
    db.session.commit()
    
    return {'success': 'User registered'}, 201

@app.route('/users', methods=['GET'])
def get_users():
    users = User.query.all()
    result = []
    for user in users:
        user_data = {}
        user_data['id'] = user.id
        user_data['firstname'] = user.firstname
        user_data['lastname'] = user.lastname
        user_data['age'] = user.age
        result.append(user_data)
    return {'users': result}, 200

if __name__ == '__main__':
    db.create_all()
    app.run(host='localhost', port=5000)

