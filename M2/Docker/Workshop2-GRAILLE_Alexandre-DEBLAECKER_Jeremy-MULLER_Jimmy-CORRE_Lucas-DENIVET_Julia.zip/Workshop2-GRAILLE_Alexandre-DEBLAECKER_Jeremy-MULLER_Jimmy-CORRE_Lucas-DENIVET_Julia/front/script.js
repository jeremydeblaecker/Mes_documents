const divUsers = `
<div class="table-row">		
  <div class="table-data">__firstname__</div>
  <div class="table-data">__lastname__</div>
  <div class="table-data">__age__</div>
</div>
`;

const htmlToElement = (html) => {
  const template = document.createElement("template");
  html = html.trim(); // Never return a text node of whitespace as the result
  template.innerHTML = html;
  return template.content.firstChild;
};
const divList = document.getElementById("list");

const fetchApiDone = (json) => {
  console.log("json:", json)
  console.log("json:", json.users)
  let array = json.users
  array.forEach((user, i) => {
    console.log('log:'+user)
    const newDivUsers = divUsers
      .replace("__firstname__", user.firstname)
      .replace("__lastname__", user.lastname)
      .replace("__age__", user.age);
    divList.appendChild(htmlToElement(newDivUsers));
  });
};


  fetch("http://www.api.loc/users").then((response) =>
  response.json().then(fetchApiDone)
  );