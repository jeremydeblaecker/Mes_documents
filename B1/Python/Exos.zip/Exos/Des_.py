import random


class Deee:

    def __init__(self):
        self.face_de = ["", """ 
                         _____ 
                        |     |
                        |  o  |
                        |     |
                        |_____|""","""
                         _____ 
                        | o   |
                        |     |
                        |   o |
                        |_____|""","""
                         _____ 
                        | o   |
                        |  o  |
                        |   o |
                        |_____|""","""
                         _____ 
                        | o o |
                        |     |
                        | o o |
                        |_____|""","""
                         _____ 
                        | o o |
                        |  o  |
                        | o o |
                        |_____|""","""
                         _____ 
                        | o o |
                        | o o |
                        | o o |
                        |_____|"""]

        self.main()
        pass

    def lancer(self, de, faces):
        r = 0
        while r < de:
            lances = random.randint(1, 6)
            r += 1
            print("Votre dé affiche : ", self.face_de[lances])
        pass

    def main(self):
        jeu = True
        while jeu:
            reponse = input("Prêt à jouer Y/N : ")
            if reponse.lower() == "y":
                de = eval(input("Choisir le nombre de dés devant apparaitre : "))
                lances = random.randint(1, 6)
                self.lancer(de, lances)
            else:
                print("Merci d'avoir joué !")
                break
        pass

de = Deee()
