import random
print("Exercice 12 : Jeu du 421")
print(random.randrange(1, 6))
print(random.randrange(1, 6))
print(random.randrange(1, 6))
if a = 4,b = 2,c = 1
    print("c'est gagné")
if a = 2 and b = 1 and c = 4
    print("c'est gagné")
if a = 1 and b = 4 and c = 2
    print("c'est gagné")
