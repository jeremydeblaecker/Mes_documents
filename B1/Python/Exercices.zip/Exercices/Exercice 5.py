choix=(input('Voulez-vous jouer ? (O,o,N, n)' ));
while choix == 'O' or 'o':
    print('Cest parti !')
while choix == 'N' or 'n':
    print('Tant pis')
