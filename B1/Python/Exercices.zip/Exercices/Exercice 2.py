nombre1=int(input("Renter votre premier nombre entier"));
nombre1=nombre1*2;
nombre2=int(input("Renter votre deuxième nombre entier"));
nombre2=nombre2*2
print('La valeur du premier nombre multiplié par 2 est :',nombre1,'La valeur du deuxième nombre multiplié par 2 est :', nombre2);

