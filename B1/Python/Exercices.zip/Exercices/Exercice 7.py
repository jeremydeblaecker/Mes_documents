A=0
i = int(input('Entrer un entier :'));
while i>=0 :
    i=int(input('Entrer un entier :'));
    A =  A + 1
print('Vous avez un total de :', A)
