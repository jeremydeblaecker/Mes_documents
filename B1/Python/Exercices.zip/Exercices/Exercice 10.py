import sys
sys.float_info.epsilon

nombreA=int(input('Entrer a:'));
nombreB=int(input('Entrer b:'));
nombreU0=int(input('Entrer U0:'));
nombreNMAX=int(input('Entrer NMAX:'));
epsilon=(input('Entrer epsilon:'));
print('Calcul de la suite Un =', nombreA, '+', nombreB , ' * Un-1 avec U0 =', nombreU0, 'et NMAX =',nombreNMAX, 'avec epsilon =', epsilon)
