from math import log10
choix=int(input('Entrer un entier :' ));
print(log10(choix))
