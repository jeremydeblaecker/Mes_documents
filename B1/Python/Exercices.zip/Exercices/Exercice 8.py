from math import factorial
choix=int(input('Entrer un entier que vous souhaitez factoriser:'));
print('La factoriel de votre choix est :', factorial(choix))
