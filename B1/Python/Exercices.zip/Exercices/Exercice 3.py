nombre1=float(input("Renter votre premier nombre réel"));
nombre2=float(input("Renter votre deuxième nombre réel"));
print('La division de vos deux réels est',nombre1/nombre2);
