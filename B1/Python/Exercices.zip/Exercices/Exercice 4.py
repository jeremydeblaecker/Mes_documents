choix=(input('Voulez-vous entrer une lettre(l) ou un entier(e) ?' ));
while choix=='l':
    lettre=str(input('Tapez la lettre:'));
    print('Votre lettre :', lettre,' et le code=', ord(lettre));
    choix=(input('Voulez-vous continuer (O, N) ?'));


while choix=='e':
    entier=int(input('Tapez un entier:'));
    print('Votre entier est : ', entier, 'et le code', chr(entier));
    choix=(input('Voulez-vous continuer (O, N) ?'));





