Calculatrice = True
while Calculatrice :

    Methode=input('Que veux-tu faire ? (+,-,*,/) ')
    Methode=str(Methode)

    if str(Methode) == '+':
        print('Tu as choisie', Methode)
        x = input("Nombre 1= ")
        y = input("Nombre 2= ")
        x = float(x)
        y = float(y)
        print('Le resultat de l addition est ', float(x) + float(y))

    if str(Methode) == '-':
        print ('Tu as choisie ', Methode)
        x = input ("Nombre 1 = ")
        y = input("Nombre 2 = ")
        x = float(x)
        y = float(y)
        print('Le resultat de ta soustraction est ', float(x) - float(y))

    if str(Methode) == '*':
        print ("Tu as choisie ", Methode)
        x = input ("Nombre 1 = ")
        y = input("Nombre 2 = ")
        x = float(x)
        y = float(y)
        print("Le resultat de ta multiplication est ", float(x) * float(y))

    if str(Methode) == '/':
        print ("Tu as choisie ", Methode)
        x = input ("Nombre 1 = ")
        y = input("Nombre 2 = ")
        x = float(x)
        y = float(y)
        print("Le resultat de ta division est ", float(x) / float(y))
