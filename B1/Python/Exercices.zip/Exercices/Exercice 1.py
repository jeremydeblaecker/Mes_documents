lettre = chr(65);
nombre = ord('A');
print ("Le nombre est", nombre ,"et la lettre est",lettre);
