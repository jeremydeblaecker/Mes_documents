import random




def rand(a, b, c):
    aff = print("Votre coup a donner :|", a, "||", b, "||", c, "|")
    return aff

def jouer():
    print("Bienvenue sur ce programme où vous allez pouvoir faire des parties de jackpot\n")
    capital=0
    choix='y'

    while choix=='y':
        choix='o'
        if choix == 'o':
            capitalN = int(input("Mettez le nombre de jeton que vous voulez r'ajouter a votre capital"))
            capital = capital + capitalN

            choix = 'yes'


        while choix=='yes':

            #test gagnant
            #a= random.choice(['2'])
            #b = random.choice(['1'])
            #c = random.choice(['1'])

            a = random.choice(
                ['カ', 'タ', 'ナ', 'ハ', 'マ', 'ヤ', 'ラ', 'ワ', 'ガ', 'ザ', 'ダ', 'バ', 'パ', '۞', '♥', '●', '♣', '♠', '■', '♦', '1',
                 '2',
                 '3', '4', '5', '6', '7', '8', '9', 'J', 'A', 'C', 'K', 'P', 'O', 'T', 'j', 'a', 'c', 'k', 'p', 'o', 't', ])
            b = random.choice(
                ['カ', 'タ', 'ナ', 'ハ', 'マ', 'ヤ', 'ラ', 'ワ', 'ガ', 'ザ', 'ダ', 'バ', 'パ', '۞', '♥', '●', '♣', '♠', '■', '♦', '1',
                 '2',
                 '3', '4', '5', '6', '7', '8', '9', 'J', 'A', 'C', 'K', 'P', 'O', 'T', 'j', 'a', 'c', 'k', 'p', 'o', 't', ])
            c = random.choice(
                ['カ', 'タ', 'ナ', 'ハ', 'マ', 'ヤ', 'ラ', 'ワ', 'ガ', 'ザ', 'ダ', 'バ', 'パ', '۞', '♥', '●', '♣', '♠', '■', '♦', '1',
                 '2',
                 '3', '4', '5', '6', '7', '8', '9', 'J', 'A', 'C', 'K', 'P', 'O', 'T', 'j', 'a', 'c', 'k', 'p', 'o', 't', ])
            print("Votre capital est de:", capital, "jetons")
            mise=int(input("Mettez le nombre de jeton que vous voulez mettre(la mise ne peut pas être au dessus de votre capital): "))
            if mise>capital:
                print("Vous ne pouvez pas vous n'avez pas assez de jeton!!!")
                choix='y'
            else:
                capital=capital-mise
                rand(a,b,c)



    #2 signe identique chiffre
            if ((a==b or a==c or b==c)):

                print("Tirage gagnant 2 signe identique votre mise a ete multiplié par 65")
                capital = capital + (mise * 65)



    #chiffre
            if ((a=='1' or a=='2'or a=='3'or a=='4'or a=='5'or a=='6'or a=='7'or a=='8'or a=='9') and (b=='1' or b=='2'or b=='3'or b=='4'or b=='5'or b=='6'or b=='7'or b=='8'or b=='9')and (c=='1' or c=='2'or c=='3'or c=='4'or c=='5'or c=='6'or c=='7'or c=='8'or c=='9')):
                print("Tirage gagnant 3 chiffres votre mise a ete multiplié par 30")
                capital=capital+(mise*30)

    #carte
            if ((a=='♥' or a=='♣'or a=='♠'or a=='♦')and (b=='♥'or b=='♣'or b=='♠'or b=='♦') and (c=='♥'or c=='♣'or c=='♠'or c=='♦')):
                print("Tirage gagnant 3 cartes tiré votre mise a ete multiplié par 40")
                capital=capital+(mise*40)

    #symbole
            if ((a=='۞'or a=='۞'or a=='۞')and(a=='●'or a=='●'or a=='●')and(a=='■'or a=='■'or a=='■')):
                print("Tirage gagnant 3 symboles tiré votre mise a ete multiplié par 50")
                capital = capital + (mise * 50)

    #katalan
            if ((a=='カ' or a=='タ' or a=='ナ'or a=='ハ'or a=='マ'or a=='ヤ'or a=='ラ'or a=='ワ'or a=='ガ' or a=='ザ'or a=='ダ'or a=='バ'or a=='パ') and(b=='カ' or b=='タ' or b=='ナ'or b=='ハ'or b=='マ'or b=='ヤ'or b=='ラ'or b=='ワ'or b=='ガ' or b=='ザ'or b=='ダ'or b=='バ'or b=='パ')and(c=='カ' or c=='タ' or c=='ナ'or c=='ハ'or c=='マ'or c=='ヤ'or c=='ラ'or c=='ワ'or c=='ガ' or c=='ザ'or c=='ダ'or c=='バ'or c=='パ')):
                print("Tirage gagnant 3 signes katakan votre mise a ete multiplié par 10")
                capital = capital + (mise * 10)

    #miniscule
            if((a=='j'or a=='a'or a=='c'or a=='k'or a=='p'or a=='o'or a=='t')and(b=='j'or b=='a'or b=='c'or b=='k'or b=='p'or b=='o'or b=='t')and(c=='j'or c=='a'or c=='c'or c=='k'or c=='p'or c=='o'or c=='t')):
                print("Tirage gagnant 3 minuscules votre mise a ete multiplié par 25")
                capital = capital + (mise * 25)

    #majuscule
            if ((a=='J' or a=='A'or a=='C'or a=='K'or a=='P'or a=='O'or a=='T')and(b=='J' or b=='A'or b=='C'or b=='K'or b=='P'or b=='O'or b=='T')and(c=='J' or c=='A'or c=='C'or c=='K'or c=='P'or c=='O'or c=='T')):
                print("Tirage gagnant 3 majuscules votre mise a ete multiplié par 30")
                capital = capital + (mise * 30)

    #identique majuscule
            if ((a==b and a==c and b==c)):
                print("Tirage gagnant 3 signes indentiques votre mise a ete multiplié par 100")
                capital = capital + (mise * 100)



            choix = input("Voulez vous refaire un lancer(yes/n)")

            while choix=='n':
                print("Votre capital de : ",capital,"jetons peut être retirer")
                print("au revoir")
                return


            if capital == 0 and choix!='n':
                print("Vous n'avez plus de jeton")
                choix=input(("Voulez vous réinserez des jeton ? (y/nn)"))
                while choix=='o':
                    capitalN = int(input("Mettez le nombre de jeton que vous voulez r'ajouter a votre capital"))
                    capital = capital + capitalN
                    print("Votre nouveau capital est:", capital, "jeton")
                    choix = 'y'
                while choix == 'nn' or choix == 'n':
                    print("Au revoir")
                    return















