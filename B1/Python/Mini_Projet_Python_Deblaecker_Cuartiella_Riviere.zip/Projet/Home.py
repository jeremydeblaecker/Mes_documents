from Calcul_Volumes import Volume
from jackpot import *
from Des_ import *
from Cercles import *
from PENDU import*
from CARRE_DIVERS import *

def runcalcul(forme):

    bcl = "y"

    print("Bienvenue sur ce programme permettant de calculer les volumes dont vous avez besoin\n")
    while bcl == "y":
        print("La liste des formes calculés par le programmes est :\n")
        print("1=Cubes\n2=Parallépipède Rectangle\n3=Cylindre\n4=Sphère\n5=Pyramide\n")
        choix = int(input("Faite votre choix en mettant le bon chiffre : \n"))

        if choix == 1:
            print("Vous avez choisie le cubes\n ça formule est : V=c^3\n")
            c = int(input("c = \n"))
            print("Le volumes de votre cubes est : ", forme.cubes(c))


        if choix == 2:
            print("Vous avez choisie le parralépipède\n ça formule est V=L*l*h\n")
            lo = int(input("L ="))
            la = int(input("l ="))
            h = int(input("h ="))
            print("Le volume de votre parrallépipède rectangle est : ", forme.paralle(lo, la, h))


        if choix == 3:
            print("Vous avez choisie le cylindre\n ça formule est V=π*R^2*h\n")
            R = int(input("R ="))
            hc = int(input("h ="))
            print("Le volume de votre cylindre est : ", forme.cylindre(R, hc))


        if choix == 4:
            print("Vous avez chousie la sphère\n ça formule est V=(4π*R^3)/3\n")
            Rs = int(input("R ="))
            print("Le volume de votre sphère est : ", forme.sphere(Rs))

        if choix == 5:
            print("Vous avez choisi la pyramide\n ça formule est :V=(c^2*h)/3\n")
            cp = int(input("c ="))
            h = int(input("h ="))
            print("Le volume de votre pyramide est :", forme.pyramide(cp, h))

        bcl = input("Si vous voulez refaire (y) si vous voulez arreter(n)")

        while bcl == "n":
            return


v=Volume()
debut=True
while debut:
    choix=input("Vous choisisser quels thèmes ?\nvous avez le choix entre :\n1:Applications Graphique\n2:Application de jeux\n3:Application mathématique\n ")

    while choix=='1':
        grap=input('Vous avez choisi les applications Graphique vous avez le choix entre:\n1:Cercle Coloré\n2:Carré Divers\n ')
        if grap=='1':
            cercles()
            choix = None
        if grap=='2':
            carre()
            choix = None


    while choix=='2':
        jeux=input('Vous avez choisi les applications Jeux vous avez le choix entre\n1:Le pendu\n2:Le Jackpot\n3:Tirage de dé\n ')
        if jeux=='1':
            pendu()
            choix = None
        if jeux=='2':
            jouer()
            choix = None
        if jeux=='3':
            Deee()
            choix = None

    while choix=='3':
        mat=input("Vous avez choisi l'application de math qui est Calculer les volumes appuyer sur 'y'pour executer l'application\n ")
        if mat=='y':
            runcalcul(v)
            choix=None


