import random


def Lance (de, faces):
    r = 0
    while r < de:
        lances = random.randint(1, faces)
        r += 1
        print("Votre dé affiche : ", FaceDe[lances])


def main():
    jeu = True
    while jeu:
        reponse = input("Prêt à jouer Y/N : ")
        if reponse.lower() == "y":
            de = eval(input("Choisir le nombre de dés devant apparaitre : "))
            faces = eval(input("Entrer le nombre de faces de votre dé : "))
            Lance(de, faces)
        else:
            print("Merci d'avoir joué !")
            return

FaceDe=("",""" 
 _____ 
|     |
|  o  |
|     |
|_____|""",""" 
 _____ 
| o   |
|     |
|   o |
|_____|""",""" 
 _____ 
| o   |
|  o  |
|   o |
|_____|""",""" 
 _____ 
| o o |
|     |
| o o |
|_____|""",""" 
 _____ 
| o o |
|  o  |
| o o |
|_____|""",""" 
 _____ 
| o o |
| o o |
| o o |
|_____|"""        )

