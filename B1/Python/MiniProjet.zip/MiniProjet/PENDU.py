import os
import pickle
from random import choice
def recup_scores(le_fichier_scores):
# cette fonction va servir a récupérer les scores enregisrtés si le fichier existe.
    if os.path.exists(le_fichier_scores): # Le fichier existe
            # On le récupère
            fichier_scores = open(le_fichier_scores, "rb")
            mon_depickler = pickle.Unpickler(fichier_scores)
            scores = mon_depickler.load()
            fichier_scores.close()
    else: # Le fichier n'existe pas
            scores = {}
    return scores
#---------------------------------------------------------------------------------------------------------------------------------------------------------
def enregistrer_scores(scores,le_fichier_scores):
    fichier_scores = open(le_fichier_scores, "wb") # On écrase les anciens scores
    mon_pickler = pickle.Pickler(fichier_scores)
    mon_pickler.dump(scores)
    fichier_scores.close()

#  éléments saisis par l'utilisateur
#---------------------------------------------------------------------------------------------------------------------------------------------------------
def recup_lettre():
#elle récupère une lettre saisit par l'utilisateur
    lettre= input("tapez une lettre:")
    """ pour renvoyer une copie de la chaîne dans laquelle
    tous les caractères sont mis en minuscule"""
    return lettre[0]
#-------------POUR NIVEAU 1-------------------------------------------------------------------------------------------------------------------------------

def choisir_mot():
    #elle renvoie le mot choisi dans la liste des mots ma_liste
    menu= int(input( "choissiez votre menu, tapez:  menu 1=niveau 1  2=niveau 2 3=niveau 3 ou 4=niveau 4 5=retour menu :"))
    if (menu== 1):
        niv1= open("NIVEAU/niv1.txt", "r")
        ligne = niv1.read()
        return choice(ligne)
        if(retourMenu==5):
            return choix_menu()
    if(menu==2):
        niv2= open("NIVEAU/niv2.txt", "r")
        ligne = niv2.read()
        return choice(ligne)
        if(retourMenu==5):
            return choix_menu()
    if(menu==3):
        niv3= open("NIVEAU/niv3.txt", "r")
        ligne = niv3.read()
        return choice(ligne)
        if(retourMenu==5):
            return choix_menu()
    if(menu==4):
        niv4= open("NIVEAU/niv4.txt", "r")
        ligne = niv4.read()
        return choice(ligne)
        if(retourMenu==5):
            return choix_menu()
#------------------------------------------------------------------------------------------------------------------------------------------------------------
def recup_mot_en_coeur(mot_complet, lettres_trouvees):
    # elle renvoie un mot masqué par un coeur
     mot_masque = ""
     for lettre in mot_complet:
        if lettre in lettres_trouvees:
            mot_masque += lettre
        else:
            mot_masque += "♥"
     return mot_masque

#--------------------------------------------------------------------------------------------------------------------------------------------------------------

def pendu():
    #Nbre de coups par partie
    nbre_coups= 8

    #Le nom du fichier ou l'on stock les scores
    le_fichier_scores = "scores"



    # on récupère les scores de la partie
    scores= recup_scores(le_fichier_scores)
    # Notre variable pour savoir quand arrêter la partie
    continuer_partie = 'o'

    while continuer_partie != 'n':
        mot_a_trouver = choisir_mot()
        lettres_trouvees = []
        mot_trouve = recup_mot_en_coeur(mot_a_trouver, lettres_trouvees)
        nb_chances = nbre_coups
        while mot_a_trouver!=mot_trouve and nb_chances>0:
            print("Mot à trouver {0} (encore {1} chances)".format(mot_trouve, nb_chances))
            lettre = recup_lettre()
            if lettre in lettres_trouvees: # La lettre a déjà été choisie
                print("Vous avez déjà choisi cette lettre.")
            elif lettre in mot_a_trouver: # La lettre est dans le mot à trouver
                lettres_trouvees.append(lettre)
                print("Bien joué.")
            else:
                nb_chances -= 1
                print("... non, cette lettre ne se trouve pas dans le mot...")
            mot_trouve = recup_mot_en_coeur(mot_a_trouver, lettres_trouvees)

        # A-t-on trouvé le mot ou nos chances sont-elles épuisées ?
        if mot_a_trouver==mot_trouve:
            print("Félicitations ! Vous avez trouvé le mot {0}.".format(mot_a_trouver))
        else:
            print("PENDU !!! Vous avez perdu.")

        # On met à jour le score de l'utilisateur
        scores += nb_chances

        continuer_partie = input("Souhaitez-vous continuer la partie (O/N) ?")
        continuer_partie = continuer_partie.lower()

    # La partie est finie, on enregistre les scores
    enregistrer_scores(scores)

    # On affiche les scores de l'utilisateur
    print("Vous finissez la partie avec {0} points.".format(scores))

