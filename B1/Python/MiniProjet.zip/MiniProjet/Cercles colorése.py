from turtle import *
class cercles :


    import random
    setup()
    cercle = Turtle()

    de = True
    while de :
        reponse = input("Prêt à jouer Y/N : ")
        if reponse.lower() == "y":
            choixc = input("De quel couleur doit être votre cercle (en anglais)?")
            choixt = input("De quel taille doit être le trait (1 à 9)")
            cercle.up()
            cercle.goto(-200,0) #permet de centré le cercle
            cercle.down()
            cercle.width(choixt)     #épaisseur du trait
            cercle.hideturtle() #cache les flèches qui créée le cercle
            #vitesse de création du cercle de 1 à 10
            cercle.speed(0)
            for i in range(180):
                #Permet de choisir une couleur
                cercle.color(choixc)
                cercle.forward(400)
                cercle.right(181)
            cercle.reset() #permet d'effacer le cerlce précedent à chaque jeu

        else :
            print("Merci d'avoir joué !")
            break


myobject = cercles()

