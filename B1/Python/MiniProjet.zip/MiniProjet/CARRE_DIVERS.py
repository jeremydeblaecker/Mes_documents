from turtle import *
# Notre variable pour savoir quand arrêter la partie

def dessine_carre(choixc,choixt,H,E):
    speed(0)
    y = 0
    x = 0
    q = (choixt) // E
    if (H == 2):
        for i in range(4):
            color(choixc)
            forward(choixt)  # Côté
            left(90)  # Angle
        for ligneV in range(q):
            up()
            goto(0, E + y)
            color(choixc)
            down()
            forward(choixt)
            up()
            goto(0, E + y)
            down()
            forward(choixt)
            y = y + 10
    if (H == 3):
        for i in range(4):
            color(choixc)
            forward(choixt)  # Côté
            left(90)  # Angle
        for ligneH in range(q):
            up()
            goto(E + x, 0)
            color(choixc)
            left(90)
            down()
            forward(choixt)
            up()
            goto(E + x, 0)
            setheading(0)
            down()
            up()
            forward(choixt)
            x = x + 10
    if (H == 1):
        for i in range(1):
            up()
            color(choixc)
            forward(choixt)  # Côté
            left(90)  # Angle
            down()

def carre():
    continuer_partie = 'o'
    while continuer_partie == 'o':
        choixc =input("De quel couleur doit être votre carré (en anglais)?")
        black = 1
        choixt = float(input("De quel taille doit être le carré (1 à 9)"))
        if(choixt==1):
            choixt=50
        if(choixt==2):
            choixt=100
        if(choixt==3):
            choixt=150
        if(choixt==4):
            choixt=200
        if(choixt==5):
            choixt=250
        if(choixt==6):
            choixt=300
        if(choixt==7):
            choixt=350
        if(choixt==8):
            choixt=400
        if(choixt==9):
            choixt=450
        H= int(input( "choissiez le type de hachures entre pas de hachures=1 hachures verticales=2 et hachures horizontales=3:"))
        E= float(input( "choissiez le niveau d'écartement entre 1(peu écartés) à 9(trés écartés:"))
        if(E==1):
            E=2
        if(E==2):
            E=3
        if(E==3):
            E=4
        if(E==4):
            E=5
        if(E==5):
            E=6
        if(E==6):
            E=7
        if(E==7):
            E=8
        if(E==8):
            E=9
        if(E==9):
            E=10

        clear()
        reset()
        dessine_carre(choixc,choixt,H,E)
        continuer_partie = input("Souhaitez-vous continuer la partie (O/N) ?")
    while continuer_partie=='N' or continuer_partie=='n':
               print('au revoir')
               break

