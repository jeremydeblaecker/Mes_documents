from math import *


class Volume:

    V=0

    @staticmethod
    def cubes(self, c):
        V=c*c*c
        return V

    def paralle(self,lo,l,h):
        V=lo*l*h
        return V

    def cylindre(self, r, hc):
        V=pi*(r*r)*hc
        return V

    def sphere(self, rs):
        V=((4*pi)*(rs*rs*rs))/3
        return V

    def pyramide(self, cp,h):
        V=((cp*cp)*h)/3
        return V













