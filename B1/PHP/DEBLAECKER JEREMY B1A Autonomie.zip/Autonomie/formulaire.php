<html>
    <head>
        <meta charset="UTF-8">
        <title>Connexion</title>
    </head>
    <body>
        <h1>Connexion utilisateur</h1>
        <form action="bdd.php" method="GET">
            <label for="nom">Prenom :</label>
            <input type="text" name="login" id="prenom" required />
            <input type="submit" value="Connexion">
        </form>
    </body>
</html>