<?php
    $param = parse_ini_file('db.ini');
    if(!isset($_GET['login'])){
        echo "Le prenom que vous avez entré n'est pas présent dans la base de données";
        return;
    }
    $prenom = $_GET['login'];
    try {
        $auto = new PDO($param['url'], $param['user'], $param['pass']);
    } catch (PDOExeption $e) {
    echo $e->getMessage() ."<br>";
    echo $e->getCode() ."<br>";
    }

    $rqt = "SELECT * FROM utilisateur WHERE prenom = '$prenom'; ";

    $stmt = $auto->query($rqt);

    if ($ligne = $stmt->fetch(PDO::FETCH_ASSOC)) {
        foreach($ligne as $key => $val) {
            if ($val == $prenom) {   
                echo'Vous êtes connecté :'.$val;
                echo'Vos compétences sont :';
                $sql = 'SELECT id_competence FROM competence_utilisateur';
                $req = mysql_query($sql) or die('Erreur SQL !<br />'.$sql.'<br />'.mysql_error());
                $data = mysql_fetch_array($req);
                mysql_free_result ($req);
                mysql_close ();
            }
        }
    }else{
        echo 'Non présent dans la base de données';
        
    }
?> 

<!doctype html>
<html>
<head>
    <meta charset="UTF-8" />
    <title>Résultat de l'authentification</title>
</head>
<body>

    <?php
    if (isset($authOK)) {
        echo '<a href="index.php">Poursuivre vers la page d\'accueil</a>';
    }
    else { ?>
        <p><a href="formulaire.php">Retour vers le formulaire de connexion</p>
    <?php } ?>
</body>
</html>