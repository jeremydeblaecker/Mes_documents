#include "exo.h"
#include "stdio.h"

void Exo2(){
    /*Exercice 2*/
    int A = 6;
    int B = 2;
    printf("Exercice 2:%d \r\n",(A+B)*2);

}
