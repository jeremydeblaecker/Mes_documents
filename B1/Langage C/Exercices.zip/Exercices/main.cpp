#include <QCoreApplication>
#include "stdio.h"
#include "exo.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    /*Exo1();
    Exo2();
    Exo4();
    Exo5();
    Exo6();
    Exo7();
    Operateur();
    Exo8();*/
    Exo9();
    /*Exo10();
    Exo11();
    Exo12();
    Exo13();
    Exo14();
    Exo15();
    Exo16();
    Exo17();
    Exo18();
    Exo19();
    Exo20();
    Exo21();
    Exo22();
    Exo23();
    Exo24();*/

    return a.exec();
}


