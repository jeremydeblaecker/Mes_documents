#include "exo.h"
#include "stdio.h"
#include "math.h"

void Exo7(){
    /*Exercice 7*/

    printf("Exercice 7:\r\n");
    int ent='o';
    while(ent=='o' ||ent=='O'){
        fflush(stdin);
        printf("Entrez un entier :\r\n");
        scanf("%d",&ent);
        printf("LN de votre entier est :ln(%d)=%f\r\n",ent,log(ent));
        printf("Vous voulez continuer (O,o ou N,n)?");
        fflush(stdin);
        scanf("%c",&ent);
        while (ent!='o'&& ent!='O'&& ent!='n'&& ent!='N'){
            printf("ERREUR\r\n");
            printf("Voulez vous continuer(O,o ou N,n)?\r\n");
            scanf("%c", &ent);

        }
        while(ent=='n'||ent=='N')
        {
            printf("Au revoir\r\n");
            return;

        }
    }
}
