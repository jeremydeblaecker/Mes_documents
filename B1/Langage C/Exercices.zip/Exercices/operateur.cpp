#include "exo.h"
#include "stdio.h"

void Operateur(){
    /*Opérateur*/
    printf("Opérateur:\r\n");
    {
        int i=8;
        int* iptr = &i;
        printf("Voici i et son adresse %d , %p\n",i,&i);
        printf("Voici iptr et son adresse %p , %p, %d\n ",iptr,&iptr,*iptr);
        *iptr=5;
        printf("Voici i et son adresse %d , %p\n",i,&i);
        printf("Voici iptr et son adresse %p , %p, %d\n ",iptr,&iptr,*iptr);
    }
}
