#include <QCoreApplication>
#include <stdio.h>
void Exo10(){

    /*Exercice 10*/
    int main(int argc, char *argv[]);
    printf("Exercice 10 : \r\n");
    char operateur, reponse;
    float operant1;
    float operant2;
    float resultat = 0.0;

    while(true){

        printf("Veuillez taper votre operation:\n");
        scanf("%f%c%f", &operant1, &operateur, &operant2);
        while (operateur != '+' && operateur != '-' && operateur != '*' && !(operateur == '/' && operant2 != 0)) {
            printf("Erreur !\nSaisissez à votre operation: ");
            scanf("%f%c%f", &operant1, &operateur, &operant2);
            getchar();
        }
        if (operateur == '+') {
            resultat = operant1 + operant2;
            printf("Le resultat de l'addition est: %.2f\n", resultat);
        }

        if (operateur == '-') {
            resultat = operant1 - operant2;
            printf("Le resultat de la soustraction est: %.2f\n", resultat);
        }

        if (operateur == '*') {
            resultat = operant1 * operant2;
            printf("Le resultat de la multiplication est: %.2f\n", resultat);
        }

        if (operateur == '/') {
            resultat = operant1 / operant2;
            printf("Le resultat de la division est: %.2f\n", resultat);
        }
            printf("Voulez-vous continuer ? (y/n)");
            fflush(stdin);
            scanf("%c",&reponse);
            getchar();
            printf("%c", reponse);
        if (reponse != 'y'){
            return;
        }
    }
    }
