#include "exo.h"
#include "stdio.h"

void Exo4(){
    /*Exercice 4*/
    float C = 5;
    float D = 2;
    printf("Exercice 4 : %.2f\r\n",C/D);

}
