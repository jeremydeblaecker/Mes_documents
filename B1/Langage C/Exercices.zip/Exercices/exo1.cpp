#include "exo.h"
#include "stdio.h"

void Exo1(){
    /*Exercice 1*/
    char i = 'A' ;
    int nbr = 65;
    printf(" Exercice 1:%c %d \r\n",i , nbr);
}
