#include "exo.h"
#include "stdio.h"
#include "stdlib.h"


void Exo19() {
    printf("Exercice 19 : \n\r");

    int d,a,b, c;

    a = 0;
    b = 1;
    c = 0;

    printf ("Indiquer le nombre que vous voulez calculer avec la suite de Fibonacci : "); //Fibonacci(8)=21
    scanf ("%d", &d);
    getchar();

    if (d==0 || d==1)
    {
        printf("Fibonacci(%d)=%d", d, d);
    }

    else
    {
        for (int i=2; i<=d; i++)
        {
            a = b + c;
            c = b;
            b = a;
        }
    }

    printf ("Fibonnaci(%d)= %d\n", d, a);
}
