#include "exo.h"
#include <stdlib.h>
#include "stdio.h"
void Exo12(){
    /*Exercice 12*/


    int i = -42, j = 345;
    int *ptr1, *ptr2;
    ptr1 = &i;
    ptr2 = &j;
    printf("i=%d j=%d \nptr1=%p ptr2=%p \n",*ptr1,*ptr2,ptr1,ptr2);

    ptr1= (int*)malloc(sizeof(int));
    *ptr1=20;
    ptr2= (int*)malloc(sizeof(int));
    *ptr2=10;
    printf("ptr1=%d ptr2=%d \nptr1=%p ptr2=%p \n",ptr1[0],*ptr2,ptr1,ptr2);
    free(ptr1);
    free(ptr2);

}
