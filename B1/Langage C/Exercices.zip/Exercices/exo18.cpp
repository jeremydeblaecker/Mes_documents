#include "exo.h"
#include "stdio.h"
#include "stdlib.h"
#include <time.h>

void Exo18(){
    printf("Exercice 17 : \n\r");

    int faces;
    int lance_de;

    srand(time(NULL));
    printf("Indiquer le nombre de faces de votre de : ");
    scanf ("%d", &faces);
    lance_de = rand()% faces+1;

    printf("Votre de affiche : %d\n", lance_de);
}

