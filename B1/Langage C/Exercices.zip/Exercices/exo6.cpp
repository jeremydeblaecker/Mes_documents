#include "exo.h"
#include "stdio.h"

void Exo6(){
    /*Exercice 6*/
    printf("Exercice 6: ");
    int choix ='y';

    while (choix =='y' || choix =='Y'){
        printf("Voulez-vous jouer ?(O,o ou N,n\r\n)");
        choix = getchar(); getchar();
        while(choix =='o' || choix =='O'){
            printf("C'est parti!\r\n");
            break;
        }
        while(choix=='n'||choix=='N' ){
            printf("tant pis\r\n");
            break;
        }
        printf("Voulez vous arreter ou continuer ?(n,N ou O,o)\r\n");
        choix = getchar();
        getchar();
        while(choix=='n' || choix=='N'){
            printf("Merci d'avoir jouer\r\n");
            return;
        }
    }
        printf("fin ");
}
