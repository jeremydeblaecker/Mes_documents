#include "exo.h"
#include "stdio.h"
#include "stdlib.h"
#include "math.h"

void Exo20() {
    printf("Exercice 20\n \r");

    char choix;
    double operand;
    int boucle=0;

    do {

        printf("Exponentielle ou sinus (e ou s)?\t");
        scanf("%c", &choix);
        getchar();
        if(choix=='s'){
            printf("Entrer le sinus que vous voulez calculer \t");
            scanf("%lf", &operand);
            getchar();
            printf("Le sinus de %.0lf est %.4f\n", operand, sin(operand));

        }
        else if (choix=='e'){
            printf("Entrer l'exponentielle que vous voulez calculer :  \t");
            scanf("%lf", &operand);
            getchar();
            printf("L'exponentielle de %.0lf est %.4f\n", operand, exp(operand));

        }

    }
    while(boucle==0);
}
