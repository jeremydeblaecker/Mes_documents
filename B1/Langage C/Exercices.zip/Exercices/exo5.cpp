#include "exo.h"
#include "stdio.h"

void Exo5(){
    /*Exercice 5*/
    char E ;
    int F;
    int rep='o';
    do{

    fflush(stdin);
    printf("Entrer une lettre:  ");
    scanf("%c",&E);
    printf("Lettre : %c code : %d \r\n",E,E);
    printf("Entrer un entier:  ");
    scanf("%d",&F);
    printf("Lettre : %c code : %d \r\n",F,F);

    printf("Voulez vous continuer : (o,O ou n,N) ?\r\n");
    scanf(" %c",&rep);
           while(rep!= 'o' && rep!='O' && rep!='n' && rep!='N'){

                printf("Error \r\n");
                printf("Voulez vous continuer (o,O ou n,N)");
                scanf("%c",&rep);
            }

    }
    while(rep=='o' || rep=='O');
    if(rep =='n' || rep=='N'){
                printf("bye \r\n");
                return;
            }

}
