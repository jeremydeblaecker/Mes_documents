#include "exo.h"
#include "stdio.h"

void Exo8(){
    /*Exercice 8*/
    printf("Exercice 8:\r\n");
    int ent =0;
    int conteur=0;
    char boucle='y';
    while(ent>=0|| boucle=='y'){
        fflush(stdin);
        printf ("Entrer un nombre positif ou negatif\r\n");
        scanf("%d",&ent);
        getchar();
        conteur= ++conteur;
        while (ent<0){
            printf("Votre entier est negatif:\r\n");
            printf("Votre entier positif:%d\r\n", conteur-1);
            printf("Souhaitez vous poursuivre : (N,n)\r\n");
            fflush(stdin);
            scanf("%c", &boucle);
            getchar();
            while (boucle!='y' && boucle!='n' && boucle!='N'){
                printf("Probleme\r\n");
                break;
            }
            if(boucle=='n' || boucle == 'N'){
                printf("Au revoir");
                return;
            }
            else if (boucle=='y'){
                conteur=0;
                break;
            }
        }
    }

}
