#include "exo.h"
#include "stdio.h"

void Exo9(){
    /*Exercice9*/
    printf("Exerice 9\r\n");
    int i, n, resultat;
    char choix = 'y';

    printf ("Voulez vous utiliser for ou while?(f,w)");
    fflush(stdin);
    scanf("%c", &choix);
    if(choix=='f'){
        printf("Entrer un nombre entier positif:\r\n");
        scanf("%d", &n);
        resultat = 1;
        for (i=2;i<=n;++i)
        {
            resultat = resultat*i;
            printf("La factorielle de %d est : %d\r\n", i, resultat);

        }
    }else if (choix=='w') {
        printf("Entrer un entier positif:\r\n");
        scanf("%d", &n);
        i = 1;
        resultat= 1;
        while (i<n)
        {
            ++i;
            resultat = resultat * i;
            printf("La factorielle de %d est : %d\r\n", i, resultat);
        }

    }

}
