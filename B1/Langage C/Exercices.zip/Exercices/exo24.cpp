#include "stdio.h"
#include "stdlib.h"
/*Exercice 24*/
enum Sexe {INCONNU = 0, Masculin = 1, Feminin = 2};

struct personnes{

    char* nom[16];
    int age;
    Sexe sexe;

} ;

personnes* creer_Personnes(personnes* toto, int nbPersonne){

    toto = (personnes*)malloc(sizeof(personnes)  * nbPersonne);
    return toto;
}

personnes* initialiser_personnes(personnes* toto, int nbPersonnes){

    for(int i = 0; i < nbPersonnes; i++){

        scanf("%15s", toto[i].nom);
        scanf("%d", &toto[i].age);
    scanf("%d", &toto[i].sexe);
    }

    return toto;
}

void Afficher_personnes(personnes toto){
    if(toto.sexe == Masculin) { printf("nom : %s ,  age : %d, sexe : Masculin", toto.nom, toto.age);}
    else{
printf("nom : %s ,  age : %d, sexe : Feminin", toto.nom, toto.age);
    }
}

void personnes_free(personnes** toto){
    free(toto);
}

void Exo24(){

    int nbPersonnes, index;
    personnes* toto;

    printf("Indiquer le nombre de personne : ");
    scanf("%d", &nbPersonnes);

    toto = creer_Personnes(toto,nbPersonnes);

    toto = initialiser_personnes(toto,nbPersonnes);

    scanf("%d", &index);

    if(index == 0){
        return;
    }else if(index >= nbPersonnes && index > 0){
        Afficher_personnes(toto[index - 1]);
    }

    personnes_free(&toto);

}
