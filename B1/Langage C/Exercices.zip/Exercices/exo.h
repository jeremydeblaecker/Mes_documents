#ifndef EXO_H
#define EXO_H

    void Exo1();
    void Exo2();
    void Exo4();
    void Exo5();
    void Exo6();
    void Exo7();
    void Operateur();
    void Exo8();
    void Exo9();
    void Exo10();
    void Exo11();
    void Exo12();
    void Exo13();
    void Exo14();
    void Exo15();
    void Exo16();
    void Exo17();
    void Exo18();
    void Exo19();
    void Exo20();
    void Exo21();
    void Exo22();
    void Exo23();
    void Exo24();


#endif // EXO_H
