#include "exo.h"
#include "stdio.h"

void Exo14(){


        int tab[5][5] = {{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0},{0,0,0,0,0}};//déclaration du tableau et de sa taille
        int y, x, valeur;
        int b, c;
        int e, f;
        do{
        printf("Indice Longueur:\n");
        scanf("%d", &x);
        printf("Indice Largeure:\n");
        scanf("%d", &y);
        printf("Quelle valeur voulez-vous rentrez?\n");
        scanf("%d", &valeur);
        tab[x][y]=valeur;//injection de la valeur dans le tableau
        printf("voulez-vous encore rentrez des valeur?(0 pour consulter le tableau/1 pour encore entrer des valeurs)\n");
        scanf("%d", &b);
        }
        while(b!=0);

        do{
        printf("Quelle case souhaitez -vous voir?\n\n");
        printf("Indice Longueur:\n");
        scanf("%d", &e);
        printf("Indice Largeure:\n");
        scanf("%d", &f);
        printf("valeur de cette case: %d\n\n", tab[e][f]);//le programme affiche la valeur demandée par les coordonnées
        printf("voulez-vous encore consulter le tableau?(0 pour terminer/1 pour chercher une autre valeur)\n");
        scanf("%d", &c);
        }
        while(c!=0);
        return;
    }
