#include <QCoreApplication>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void Exo15(){
    /*Exercice 15*/
    int tab[4] ={1, 5 , 8, 10}, i =0;
      for(i =0; i <4; i++){
          printf("Adresse de pointage du tableau: %p\n", (tab +i));
          printf("Valeur a cette adresse: %d\n\n", *(tab +i));}

    return;
}



