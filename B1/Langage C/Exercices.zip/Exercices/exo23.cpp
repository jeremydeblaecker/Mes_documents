#include "stdio.h"


#define DEUBEGEUR() printf("\r\nNous sommes a la ligne %d du fichier %s\r\n\r\n",__FILE__,__LINE__);

void Exo23(){


    DEUBEGEUR();

}
