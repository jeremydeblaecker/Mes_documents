#include "exo.h"
#include "stdio.h"
#include "stdlib.h"

void Exo13(){

    /*Exercice 13*/
    int tab [10];
    int i;
    float somme , moyenne;
    for (i=0; i<6; i++)
    {
        printf("Tapez les valeurs : \n");
        scanf("%d", &tab[i]);
    }
    somme = 0;
    for (i=0; i<6; i++)
    {
        somme = somme + tab[i];
    }
    moyenne = somme / 6;
    printf("La moyenne = %f", moyenne);
}
