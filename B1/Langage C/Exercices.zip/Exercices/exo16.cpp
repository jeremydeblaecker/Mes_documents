#include <QCoreApplication>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void Exo16(){
    /*Exercice 16*/
    int main(int argc, char *argv[]);
    char tabl [1024];

    printf("Entrez une chaine de caractere \n");

    scanf("%1023s", tabl);

    for(int i = 0; i  < strlen(tabl); i++ ){

        printf("Caractere :%c Adresse :%p\n", tabl[i], &tabl[i]);

    }
}
