#include "exo.h"
#include "stdio.h"
#include "stdlib.h"

void Exo17(){
    printf("Exercice 17 : \n\r");

    int lance_de;

    lance_de = rand()% 6+1;

    printf("Votre valeur au hasard entre 1 et 6 est : %d\n", lance_de);
}
