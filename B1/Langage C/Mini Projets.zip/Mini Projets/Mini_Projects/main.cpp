#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    char * tab[] = {"titi","tutu","toto","arbre","arme"};
    char * tab2[] = {"toto","toto1","toto2","xylophone","zebre"};
    int i;
    int n = sizeof tab / sizeof * tab;
    int n2 = sizeof tab2 / sizeof * tab2;
    int ok = 1;

    for(i = 1 ; i < n ; i++)
    {
        if(strcmp(tab[i-1],tab[i]) > 0)
        {
            ok = 0;
            break;
        }
    }

    printf("ok = %d\n",ok);

    ok = 1;

    for(i = 1 ; i < n2 ; i++)
    {
        if(strcmp(tab2[i-1],tab2[i]) > 0)
        {
            ok = 0;
            break;
        }
    }

    printf("ok = %d\n",ok);


    return 0;
}
