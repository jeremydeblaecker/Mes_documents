//alert(document.getElementById("test").innerHTML=("Adieu"));
document.getElementById("test").setAttribute("pouet","coucou");
document("test").classlit.contains("big");
