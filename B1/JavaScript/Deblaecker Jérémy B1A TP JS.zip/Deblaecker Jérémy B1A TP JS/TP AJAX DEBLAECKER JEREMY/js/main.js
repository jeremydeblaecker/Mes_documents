function sendQueryWithCallback(url, method, callbackFunction) {
    (!method) ? method = 'GET' : null;
    const xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (this.readyState === 4 && this.status === 200) {
            callbackFunction(xhr.responseText);
        }
    }
    xhr.open("GET", url, true);
    xhr.send();
}

/*Récupére les informations de la barre de recherche et les envoie vers le site de la météo et récupère les informations demandées */
let intervalID;
document.getElementById('bardercherche').addEventListener('change', () => { clearTimeout(intervalID); sendQueryWithCallback('http://api.openweathermap.org/data/2.5/weather?q=' + document.getElementById("bardercherche").value + '&appid=1d722555df649fba714f0391e0adda8a', 'GET', refresh); });
function refresh(response) {
    jd(response);
    intervalID = setTimeout(refresh, 5000, response); //Met à jour les infos tous les 5 secondes
}
/*Récupére les informations de la météo afin de les afficher*/ 
function jd(response) {
    response = JSON.parse(response);
    console.log(response.main.humidity);//On récupére l'humidité
    document.getElementById("humidite").innerText = ('Humidité: ' + response.main.humidity + '%'); //On affiche l'humdité
    console.log(response.main.pressure);//On récupére la pression
    document.getElementById("pression").innerText = ('Pression: ' + response.main.pressure + ' hPa');
    console.log(response.main.temp);//On récupére la température
    document.getElementById("temperature").innerText = ('Température: ' + Math.round((response.main.temp - 273.1) * 100) / 100 + ' °C');
    console.log(response.weather[0].main);//On récupére le temps
    document.getElementById("temps").innerText = ('Temps: ' + response.weather[0].main + ' (' + response.weather[0].description + ')');
    console.log(response.coord.lon);//On récupére la longitude
    document.getElementById("longidtude").innerText = ('Longitude: ' + response.coord.lon);
    console.log(response.coord.lat);//On récupére la latitude
    document.getElementById("latitude").innerText = ('Latitude: ' + response.coord.lat);
    console.log(response.wind.speed);//On récupére la vitesse du vent
    document.getElementById("vvent").innerText = ('Vitesse vent: ' + response.wind.speed + 'm/s');
    console.log(response.wind.deg);//On récupére l'angle du vent
    document.getElementById("avent").innerText = ('Angle: ' + response.wind.deg + '°');
}