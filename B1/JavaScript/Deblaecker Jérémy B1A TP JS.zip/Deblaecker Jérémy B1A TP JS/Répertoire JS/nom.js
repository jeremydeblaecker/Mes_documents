//Récupére l'élément inscrit
let nom = document.getElementById('nom');
nom.addEventListener('keyup', filterNames);

function filterNames() {
    // Récupére la valeur de l'input
    let filterValue = document.getElementById('nom').value.toUpperCase();

    // Récupére les noms dans l'ul
    let ul = document.getElementById('names');
    // Récupére les infos dans les li
    let li = ul.querySelectorAll('li.collection-item');

    // Recherche dans les li
    for (let i = 0; i < li.length; i++) {
        let a = li[i].getElementsByTagName('a')[0];
        // Si il y a une correspondance
        if (a.innerHTML.toUpperCase().indexOf(filterValue) > -1) {
            li[i].style.display = '';
        } else {
            li[i].style.display = 'none';
        }
    }

}