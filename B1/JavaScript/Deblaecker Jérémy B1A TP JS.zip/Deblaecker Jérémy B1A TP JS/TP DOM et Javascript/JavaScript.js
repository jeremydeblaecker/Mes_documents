function displayPanel(el) {
const panels = document.getElementsByClassName('panel'); //Créer une const qui permet de récupérer les class panel
console.log(el);
for(let i=0; i<panels.length; i++){
    let panel = panels[i];
    panel.classList.remove('active') //Retire la class active de l'élément sur l'écran afin d'afficher une autre page
    console.log(el.dataset.panel)
    document.getElementById(el.dataset.panel).classList.add('active'); //Ajoute le status active à la page sur laquel on a cliqué afin de la voir

}
//Permet d'ouvrir le menu de navigation
  }
  function openNav() {
    document.getElementById("mySidebar").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  //Permet de fermer le menu de nav 
  function closeNav() {
    document.getElementById("mySidebar").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
  } 