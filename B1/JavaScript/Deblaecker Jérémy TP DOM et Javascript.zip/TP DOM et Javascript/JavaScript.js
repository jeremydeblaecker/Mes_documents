function displayPanel(el) {
const panels = document.getElementsByClassName('panel');
console.log(el);
for(let i=0; i<panels.length; i++){
    let panel = panels[i];
    panel.classList.remove('active')
    console.log(el.dataset.panel)
    document.getElementById(el.dataset.panel).classList.add('active');

}
  }
  function openNav() {
    document.getElementById("mySidebar").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  function closeNav() {
    document.getElementById("mySidebar").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
  } 